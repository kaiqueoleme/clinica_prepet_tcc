<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET' || empty($_POST)) {
    include_once "View/telaInicial.php";
    exit();
}
switch ($_POST) {

    // Tela inicial
    case isset($_POST[null]):
        include_once "../View/telaInicial.php";
        break;

    // Tela Inicial - Após Cadastro
    case isset($_POST["btnTelaInicial"]):
        include_once "../View/telaInicial.php";
        break;

    // Login Funcionarios
    case isset($_POST["btnLoginFuncionarios"]):
        include_once "../View/loginFuncionario.php";
        break;

    // Login Clientes
    case isset($_POST["btnLoginClientes"]):
        include_once "../View/loginCliente.php";
        break;
    
    case isset($_POST["btnLogarCliente"]):
        require_once "../Controller/UsuarioController.php";
        $uController = new UsuarioController();

        if ($uController->login($_POST["usuario"], $_POST["senha"])) {
            $usuarioLogado = unserialize($_SESSION['Usuario']);

            if ($usuarioLogado->getIdAcesso() == 1) {
                include_once "../View/dashboardCliente.php";
            } else{
            }
        } else {
            $_SESSION['erro_login'] = "Login ou senha incorretos. Tente novamente.";
            include_once "../View/loginCliente.php";
        }
        break;

    // Tela Cadastro Clientes
    case isset($_POST["btnCadastrar"]):
        include_once "../View/cadastroClientePessoa.php";
        break;

    // Cadastrar usuário - Pessoa
    case isset($_POST["btnCadastroPessoa"]):
        require_once "../Controller/PessoaController.php";
        $pController = new PessoaController();

        if ($pController->inserir(
            $_POST["nome"],
            date("Y-m-d", strtotime($_POST["data_nascimento"])),
            $_POST["telefone"],
            $_POST["rg"],
            $_POST["cpf"]
        )) {
            include_once "../View/cadastroClienteEndereco.php";
        } else {
            include_once "../View/cadastroClientePessoa.php";
        }
        break;
    
    // Cadastrar usuário - Endereço
    case isset($_POST["btnCadastroEndereco"]):
        require_once "../Controller/EnderecoController.php";
        $eController = new EnderecoController();

        if ($eController->inserir(
            $_POST["logradouro"],
            $_POST["numero"],
            $_POST["bairro"],
            $_POST["cidade"],
            $_POST["cep"]
        )) {
            include_once "../View/cadastroClienteUsuario.php";
        } else {
            include_once "../View/cadastroClienteEndereco.php";
        }
        break;     
    // Cadastrar usuário - Usuario
    case isset($_POST["btnCadastroUsuario"]):
         require_once "../Controller/UsuarioController.php";
        $uController = new UsuarioController();

        if ($_POST["senha"] !== $_POST["confirmar_senha"]) {
            $_SESSION['erro_cadastro_usuario'] = "As senhas não coincidem. Por favor, digite novamente.";
            include_once "../View/cadastroClienteUsuario.php";
            break; 
        }

        if ($uController->inserir(
            $_POST["login"],
            $_POST["senha"]
        )) {
            include_once "../View/cadastroRealizado.php";
            unset($_SESSION['id_pessoa']);
        } else {
            $_SESSION['erro_cadastro_usuario'] = "Não foi possível finalizar o cadastro do usuário. Tente novamente.";
            include_once "../View/cadastroClienteUsuario.php";
        }
        break;

    // Atualizar dados pessoais
    case isset($_POST["btnAtualizar"]):
        require_once "../Controller/UsuarioController.php";
        $uController = new UsuarioController();

        if ($uController->atualizar(
            $_POST["txtID"],
            $_POST["txtNome"],
            $_POST["txtCPF"],
            $_POST["txtEmail"],
            date("Y-m-d", strtotime($_POST["txtData"]))
        )) {
            include_once "../View/atualizacaoRealizada.php";
        } else {
            include_once "../View/operacaoNaoRealizada.php";
        }
        break;

}
?>

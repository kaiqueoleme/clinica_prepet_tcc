<?php
if(!isset($_SESSION))
    {
        session_start();
    }
class PessoaController{

    public function inserir($nome, $dataNascimento, $telefone, $rg, $cpf) {
        require_once '../Model/Pessoa.php';
        $pessoa = new Pessoa();
        $pessoa->setNome($nome);
        $pessoa->setDataNascimento($dataNascimento);
        $pessoa->setTelefone($telefone);
        $pessoa->setRG($rg);
        $pessoa->setCPF($cpf);
        $r = $pessoa->inserirBD();
        if ($r) {
            $_SESSION['Pessoa'] = serialize($pessoa);
            $_SESSION['id_pessoa'] = $pessoa->getID();
        }
        return $r;
    }

    public function atualizar($id, $nome, $cpf, $email, $dataNascimento) {
        require_once '../Model/Pessoa.php';
        $pessoa = new Pessoa();
        $pessoa->setId($id);
        $pessoa->setNome($nome);
        $pessoa->setCPF($cpf);
        $pessoa->setEmail($email);
        $pessoa->setDataNascimento($dataNascimento);
        $r = $pessoa->atualizarBD();
        $_SESSION['pessoa'] = serialize($pessoa);
        return $r;
    }

    public function login($cpf, $senha) {
        require_once '../Model/Pessoa.php';
        $pessoa = new Pessoa();
        $pessoa->carregarPessoa($cpf);
        $verSenha = $pessoa->getSenha();

        if ($senha == $verSenha) {
            $_SESSION['Pessoa'] = serialize($pessoa);
            return true;
        } else {
            return false;
        }
    }

}
